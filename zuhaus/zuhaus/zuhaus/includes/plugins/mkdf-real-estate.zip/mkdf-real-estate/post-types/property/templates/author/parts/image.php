<div class="mkdf-re-author-image">
    <?php echo get_avatar($author->ID, 308); ?>
</div>