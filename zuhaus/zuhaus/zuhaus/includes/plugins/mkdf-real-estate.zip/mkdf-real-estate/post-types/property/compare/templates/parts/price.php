<?php
$price = mkdf_re_get_real_estate_item_price($id);
?>
<span class="mkdf-ci-price">
   <?php echo mkdf_re_get_real_estate_price_html($price, $id); ?>
</span>
