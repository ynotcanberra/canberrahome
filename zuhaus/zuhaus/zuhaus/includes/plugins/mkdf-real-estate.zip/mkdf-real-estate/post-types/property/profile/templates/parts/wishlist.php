<span class="mkdf-property-whishlist-wrapper">
	<a href="javascript:void(0)" class="mkdf-property-whishlist" data-property-id="<?php echo get_the_ID(); ?>">
        <i class="fa <?php echo esc_attr( $wishlist_icon ); ?>"></i>
        <span class="mkdf-property-wishlist-text">
            <?php echo esc_attr( $wishlist_text ); ?>
        </span>
    </a>
</span>
