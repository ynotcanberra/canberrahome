<?php if (isset($enable_compare) && $enable_compare == 'yes') { ?>
    <div class="mkdf-item-compare">
        <?php echo mkdf_re_get_add_to_compare_list_button(); ?>
    </div>
<?php } ?>