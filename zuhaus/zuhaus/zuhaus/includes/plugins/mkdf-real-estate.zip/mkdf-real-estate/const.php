<?php

define('MIKADO_RE_VERSION', '1.2');
define('MIKADO_RE_ABS_PATH', dirname(__FILE__));
define('MIKADO_RE_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('MIKADO_RE_URL_PATH', plugin_dir_url( __FILE__ ));
define('MIKADO_RE_ASSETS_PATH', MIKADO_RE_ABS_PATH.'/assets');
define('MIKADO_RE_ASSETS_URL_PATH', MIKADO_RE_URL_PATH.'assets');
define('MIKADO_RE_MODULE_PATH', MIKADO_RE_ABS_PATH.'/modules');
define('MIKADO_RE_MODULE_URL_PATH', MIKADO_RE_URL_PATH.'modules');
define('MIKADO_RE_CPT_PATH', MIKADO_RE_ABS_PATH.'/post-types');
define('MIKADO_RE_CPT_URL_PATH', MIKADO_RE_URL_PATH.'post-types');
define('MIKADO_RE_SHORTCODES_PATH', MIKADO_RE_ABS_PATH.'/shortcodes');
define('MIKADO_RE_SHORTCODES_URL_PATH', MIKADO_RE_URL_PATH.'shortcodes');