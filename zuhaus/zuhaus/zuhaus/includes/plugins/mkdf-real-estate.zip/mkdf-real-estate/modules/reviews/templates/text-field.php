<div class="mkdf-comment-input-text">
	<textarea id="comment" placeholder="<?php esc_html_e( 'Comment', 'mkdf-real-estate' ) ?>" name="comment" cols="45" rows="6" aria-required="true"></textarea>
</div>
