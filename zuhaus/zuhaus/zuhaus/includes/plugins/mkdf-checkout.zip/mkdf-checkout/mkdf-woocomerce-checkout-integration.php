<?php
/*
Plugin Name: Mikado Woocommerce Checkout Integration
Description: Plugin that adds custom post type to woocommerce checkout
Author: Mikado Themes
Version: 1.0
*/

include_once 'load.php';
