<div class="mkdf-process-holder <?php echo esc_attr( $holder_classes ); ?>">
    <?php if(isset($image) && !empty($image['image_id'])) { ?>
        <div class="mkdf-process-image">
            <?php echo wp_get_attachment_image($image['image_id'], 'full'); ?>
            <?php if(!empty($number)) { ?>
                <div class="mkdf-process-add-text">
                    <?php echo esc_html($number); ?>
                </div>
            <?php } ?>
            <?php if($enable_border === 'yes') {?>
                <div class="mkdf-process-border">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                         width="123.535px" height="3.303px" viewBox="0 0 123.535 3.303" enable-background="new 0 0 123.535 3.303" xml:space="preserve">
                        <g>
                            <path d="M1.597,0C0.671,0,0,0.694,0,1.651c0,0.942,0.679,1.652,1.579,1.652c0.925,0,1.597-0.694,1.597-1.652
                                C3.176,0.694,2.511,0,1.597,0z"/>
                            <path d="M16.642,0c-0.926,0-1.598,0.694-1.598,1.651c0,0.942,0.679,1.652,1.579,1.652c0.925,0,1.597-0.694,1.597-1.652
                                C18.22,0.694,17.556,0,16.642,0z"/>
                            <path d="M31.687,0c-0.926,0-1.598,0.694-1.598,1.651c0,0.942,0.679,1.652,1.579,1.652c0.925,0,1.597-0.694,1.597-1.652
                                C33.265,0.694,32.601,0,31.687,0z"/>
                            <path d="M46.732,0c-0.926,0-1.598,0.694-1.598,1.651c0,0.942,0.679,1.652,1.579,1.652c0.925,0,1.597-0.694,1.597-1.652
                                C48.31,0.694,47.646,0,46.732,0z"/>
                            <path d="M61.777,0c-0.926,0-1.598,0.694-1.598,1.651c0,0.942,0.679,1.652,1.579,1.652c0.926,0,1.598-0.694,1.598-1.652
                                C63.355,0.694,62.691,0,61.777,0z"/>
                            <path d="M76.822,0c-0.926,0-1.598,0.694-1.598,1.651c0,0.942,0.678,1.652,1.578,1.652c0.926,0,1.598-0.694,1.598-1.652
                                C78.4,0.694,77.736,0,76.822,0z"/>
                            <path d="M91.867,0c-0.926,0-1.598,0.694-1.598,1.651c0,0.942,0.679,1.652,1.578,1.652c0.926,0,1.598-0.694,1.598-1.652
                                C93.445,0.694,92.781,0,91.867,0z"/>
                            <path d="M106.912,0c-0.926,0-1.598,0.694-1.598,1.651c0,0.942,0.679,1.652,1.578,1.652c0.926,0,1.598-0.694,1.598-1.652
                                C108.49,0.694,107.826,0,106.912,0z"/>
                            <path d="M121.957,0c-0.926,0-1.598,0.694-1.598,1.651c0,0.942,0.679,1.652,1.578,1.652c0.926,0,1.598-0.694,1.598-1.652
                                C123.535,0.694,122.871,0,121.957,0z"/>
                        </g>
                    </svg>
                </div>
            <?php } ?>
        </div>
    <?php } ?>
    <div class="mkdf-process-text-inner">
        <div class="mkdf-process-title-holder">
            <?php if(!empty($title)) { ?>
                <<?php echo esc_attr($title_tag); ?> class="mkdf-process-title" <?php echo zuhaus_mikado_get_inline_style($title_styles); ?>>
                    <?php echo esc_html($title); ?>
                </<?php echo esc_attr($title_tag); ?>>
            <?php } ?>
        </div>
        <?php if(!empty($text)) { ?>
            <div class="mkdf-process-text">
                <?php echo esc_html($text); ?>
            </div>
        <?php } ?>
    </div>
</div>