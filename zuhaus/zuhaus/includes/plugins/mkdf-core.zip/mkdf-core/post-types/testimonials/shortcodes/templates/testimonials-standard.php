<div class="mkdf-testimonial-content" id="mkdf-testimonials-<?php echo esc_attr( $current_id ) ?>">
	<div class="mkdf-testimonial-text-holder">
		<?php if ( has_post_thumbnail() || ! empty( $author ) ) { ?>
			<div class="mkdf-testimonials-author-holder clearfix">
				<?php if ( has_post_thumbnail() ) { ?>
					<div class="mkdf-testimonial-image">
						<?php echo get_the_post_thumbnail( get_the_ID(), array( 85, 85 ) ); ?>
                        <span class="mkdf-quotes-holder">
                            <span class="icon_quotations"></span>
                        </span>
					</div>
				<?php } ?>
				<?php if ( ! empty( $author ) ) { ?>
                    <div class="mkdf-testimonial-author">
                        <h5 class="mkdf-testimonials-author-name"><?php echo esc_html( $author ); ?></h5>
                        <?php if ( ! empty( $position ) ) { ?>
                            <span class="mkdf-testimonials-author-job"><?php echo esc_html( $position ); ?></span>
                        <?php } ?>
                    </div>
				<?php } ?>
			</div>
		<?php } ?>
		<?php if ( ! empty( $text ) ) { ?>
			<p class="mkdf-testimonial-text"><?php echo esc_html( $text ); ?></p>
		<?php } ?>
	</div>
</div>