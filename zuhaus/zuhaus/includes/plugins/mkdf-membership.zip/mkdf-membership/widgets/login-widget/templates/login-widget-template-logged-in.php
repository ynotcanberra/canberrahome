<?php
$current_user    = wp_get_current_user();
$name            = $current_user->display_name;
$current_user_id = $current_user->ID;
$membership_page_url = mkdf_membership_get_dashboard_page_url();
?>
<div class="mkdf-logged-in-user">
    <div class="mkdf-logged-in-user-inner">
        <a class="mkdf-user-mobile-icon" href="<?php echo esc_url($membership_page_url); ?>" target="_self">
            <span class="mkdf-user-icon-wrapper">
            <?php if ( mkdf_membership_theme_installed() ) {
                echo zuhaus_mikado_icon_collections()->renderIcon( 'lnr-user', 'linear_icons' );
            } else { ?>
                <span class="mkdf-login-icon lnr lnr-user"></span>
            <?php } ?>
        </span>
        </a>
        <span class="mkdf-user-icon-wrapper">
            <?php if ( mkdf_membership_theme_installed() ) {
                echo zuhaus_mikado_icon_collections()->renderIcon( 'lnr-user', 'linear_icons' );
            } else { ?>
                <span class="mkdf-login-icon lnr lnr-user"></span>
            <?php } ?>
        </span>
        <span class="mkdf-logged-in-user-name"><?php echo esc_html( $name ); ?></span>
    </div>
</div>
<ul class="mkdf-login-dropdown">
	<?php
	$nav_items = mkdf_membership_get_dashboard_navigation_items();
    $logout_url = mkdf_membership_get_dashboard_page_url() !== '' ? mkdf_membership_get_dashboard_page_url() : home_url( '/' );
	foreach ( $nav_items as $nav_item ) { ?>
		<li>
			<a href="<?php echo $nav_item['url']; ?>">
                <span>
				    <?php echo $nav_item['text']; ?>
                </span>
			</a>
		</li>
	<?php } ?>
	<li>
		<a href="<?php echo wp_logout_url( $logout_url ); ?>">
            <span>
			    <?php esc_html_e( 'Log Out', 'mkdf-membership' ); ?>
            </span>
		</a>
	</li>
</ul>