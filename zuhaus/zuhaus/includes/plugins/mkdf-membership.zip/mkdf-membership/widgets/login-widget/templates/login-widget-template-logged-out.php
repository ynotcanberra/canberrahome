<?php
if ( mkdf_membership_theme_installed() ) { ?>
    <a href="#" class="mkdf-login-opener">
        <?php echo zuhaus_mikado_icon_collections()->renderIcon('lnr-user', 'linear_icons') ?>
        <span class="mkdf-login-text"><?php esc_html_e('Login / Register', 'mkdf-membership'); ?></span>
    </a>
<?php } else { ?>
    <a href="#" class="mkdf-login-opener">
        <span class="mkdf-login-icon lnr lnr-user"></span>
        <span class="mkdf-login-text"><?php esc_html_e('Login / Register', 'mkdf-membership'); ?></span>
    </a>
<?php }