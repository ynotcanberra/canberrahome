// Load the SDK asynchronously
(function (d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {
        return;
    }
    js = d.createElement(s);
    js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
if (typeof mkdfSocialLoginVars !== 'undefined') {
    var facebookAppId = mkdfSocialLoginVars.social.facebookAppId;
}
if (facebookAppId) {
    window.fbAsyncInit = function () {
        FB.init({
            appId: facebookAppId, //265124653818954 - test app ID
            cookie: true,  // enable cookies to allow the server to access
            xfbml: true,  // parse social plugins on this page
            version: 'v2.5' // use version 2.5
        });

        window.FB = FB;
    };
}

(function ($) {
    "use strict";

    var socialLogin = {};
    if ( typeof mkdf !== 'undefined' ) {
        mkdf.modules.socialLogin = socialLogin;
    }

    socialLogin.mkdfUserLogin = mkdfUserLogin;
    socialLogin.mkdfUserRegister = mkdfUserRegister;
    socialLogin.mkdfUserLostPassword = mkdfUserLostPassword;
    socialLogin.mkdfInitLoginWidgetModal = mkdfInitLoginWidgetModal;
    socialLogin.mkdfInitFacebookLogin = mkdfInitFacebookLogin;
    socialLogin.mkdfInitGooglePlusLogin = mkdfInitGooglePlusLogin;
    socialLogin.mkdfUpdateUserProfile = mkdfUpdateUserProfile;
    socialLogin.mkdfRenderAjaxResponseMessage = mkdfRenderAjaxResponseMessage;

    $(document).ready(mkdfOnDocumentReady);
    $(window).load(mkdfOnWindowLoad);
    $(window).resize(mkdfOnWindowResize);
    $(window).scroll(mkdfOnWindowScroll);

    /**
     * All functions to be called on $(document).ready() should be in this function
     */
    function mkdfOnDocumentReady() {
        mkdfInitLoginWidgetModal();
        mkdfUserLogin();
        mkdfUserRegister();
        mkdfUserLostPassword();
        mkdfUpdateUserProfile();
        mkdfMembershipInitDatePicker();
        mkdfMembershipUploadImages();
        mkdfMembershipRepeater();
        mkdfMembershipInitSortable();
        mkdfMembershipInitGeocomplete();
        mkdfMembershipRemoveMedia();
    }

    /**
     * All functions to be called on $(window).load() should be in this function
     */
    function mkdfOnWindowLoad() {
        mkdfInitFacebookLogin();
        mkdfInitGooglePlusLogin();
        mkdfMembershipFullScreen();
    }

    /**
     * All functions to be called on $(window).resize() should be in this function
     */
    function mkdfOnWindowResize() {
    }

    /**
     * All functions to be called on $(window).scroll() should be in this function
     */
    function mkdfOnWindowScroll() {
    }

    /**
     * Initialize login widget modal
     */
    function mkdfInitLoginWidgetModal() {

        var modalOpener = $('.mkdf-login-opener'),
            modalHolder = $('.mkdf-login-register-holder');

        $( document.body ).on( 'open_user_login_trigger', function() {
            modalHolder.fadeIn(300);
            modalHolder.addClass('opened');
        });

        if (modalOpener) {
            var tabsHolder = $('.mkdf-login-register-content');

            //Init opening login modal
            modalOpener.click(function (e) {
                e.preventDefault();
                modalHolder.fadeIn(300);
                modalHolder.addClass('opened');
            });

            //Init closing login modal
            modalHolder.click(function (e) {
                if (modalHolder.hasClass('opened')) {
                    modalHolder.fadeOut(300);
                    modalHolder.removeClass('opened');
                }
            });
            tabsHolder.click(function (e) {
                e.stopPropagation();
            });
            // on esc too
            $(window).on('keyup', function (e) {
                if (modalHolder.hasClass('opened') && e.keyCode == 27) {
                    modalHolder.fadeOut(300);
                    modalHolder.removeClass('opened');
                }
            });

            //Init tabs
            tabsHolder.tabs();
        }
    }

    /**
     * Login user via Ajax
     */
    function mkdfUserLogin() {
        $('.mkdf-login-form').on('submit', function (e) {
            e.preventDefault();
            var ajaxData = {
                action: 'mkdf_membership_login_user',
                security: $(this).find('#mkdf-login-security').val(),
                login_data: $(this).serialize()
            };
            $.ajax({
                type: 'POST',
                data: ajaxData,
                url: mkdfGlobalVars.vars.mkdfAjaxUrl,
                success: function (data) {
                    var response;
                    response = JSON.parse(data);

                    mkdfRenderAjaxResponseMessage(response);
                    if (response.status == 'success') {
                        window.location = response.redirect;
                    }
                }

            });
            return false;
        });
    }

    /**
     * Register New User via Ajax
     */
    function mkdfUserRegister() {

        $('.mkdf-register-form').on('submit', function (e) {

            e.preventDefault();
            var ajaxData = {
                action: 'mkdf_membership_register_user',
                security: $(this).find('#mkdf-register-security').val(),
                register_data: $(this).serialize()
            };

            $.ajax({
                type: 'POST',
                data: ajaxData,
                url: mkdfGlobalVars.vars.mkdfAjaxUrl,
                success: function (data) {
                    var response;
                    response = JSON.parse(data);

                    mkdfRenderAjaxResponseMessage(response);
                    if (response.status == 'success') {
                        window.location = response.redirect;
                    }
                }
            });

            return false;
        });
    }

    /**
     * Reset user password
     */
    function mkdfUserLostPassword() {

        var lostPassForm = $('.mkdf-reset-pass-form');
        lostPassForm.submit(function (e) {
            e.preventDefault();
            var data = {
                action: 'mkdf_membership_user_lost_password',
                user_login: lostPassForm.find('#user_reset_password_login').val()
            };
            $.ajax({
                type: 'POST',
                data: data,
                url: mkdfGlobalVars.vars.mkdfAjaxUrl,
                success: function (data) {
                    var response = JSON.parse(data);
                    mkdfRenderAjaxResponseMessage(response);
                    if (response.status == 'success') {
                        window.location = response.redirect;
                    }
                }
            });
        });
    }

    /**
     * Response notice for users
     * @param response
     */
    function mkdfRenderAjaxResponseMessage(response) {

        var responseHolder = $('.mkdf-membership-response-holder'), //response holder div
            responseTemplate = _.template($('.mkdf-membership-response-template').html()); //Locate template for info window and insert data from marker options (via underscore)

        var messageClass;
        if (response.status === 'success') {
            messageClass = 'mkdf-membership-message-succes';
        } else {
            messageClass = 'mkdf-membership-message-error';
        }

        var templateData = {
            messageClass: messageClass,
            message: response.message
        };

        var template = responseTemplate(templateData);
        responseHolder.html(template);
    }

    /**
     * Facebook Login
     */
    function mkdfInitFacebookLogin() {
        var loginForm = $('.mkdf-facebook-login-holder');
        loginForm.submit(function (e) {
            e.preventDefault();
            window.FB.login(function (response) {
                mkdfFacebookCheckStatus(response);
            }, {scope: 'email, public_profile'});
        });

    }

    /**
     * Check if user is logged into Facebook and App
     *
     * @param response
     */
    function mkdfFacebookCheckStatus(response) {
        if (response.status === 'connected') {
            // Logged into your app and Facebook.
            mkdfGetFacebookUserData();
        } else if (response.status === 'not_authorized') {
            // The person is logged into Facebook, but not your app.
            console.log('Please log into this app');
        } else {
            // The person is not logged into Facebook, so we're not sure if
            // they are logged into this app or not.
            console.log('Please log into Facebook');
        }
    }

    /**
     * Get user data from Facebook and login user
     */
    function mkdfGetFacebookUserData() {
        console.log('Welcome! Fetching information from Facebook...');
        FB.api('/me', 'GET', {'fields': 'id, name, email, link, picture'}, function (response) {
            var nonce = $('.mkdf-facebook-login-holder [name^=mkdf_nonce_facebook_login]').val();
            response.nonce = nonce;
            response.image = response.picture.data.url;
            var data = {
                action: 'mkdf_membership_check_facebook_user',
                response: response
            };
            $.ajax({
                type: 'POST',
                data: data,
                url: mkdfGlobalVars.vars.mkdfAjaxUrl,
                success: function (data) {
                    var response;
                    response = JSON.parse(data);

                    mkdfRenderAjaxResponseMessage(response);
                    if (response.status == 'success') {
                        window.location = response.redirect;
                    }
                }
            });

        });
    }

    /**
     * Google Login
     */
    function mkdfInitGooglePlusLogin() {

        if (typeof mkdfSocialLoginVars !== 'undefined') {
            var clientId = mkdfSocialLoginVars.social.googleClientId;
        }
        if (clientId) {
            gapi.load('auth2', function () {
                window.auth2 = gapi.auth2.init({
                    client_id: clientId
                });
                mkdfInitGooglePlusLoginButton();
            });
        } else {
            var loginForm = $('.mkdf-google-login-holder');
            loginForm.submit(function (e) {
                e.preventDefault();
            });
        }

    }

    /**
     * Initialize login button for Google Login
     */
    function mkdfInitGooglePlusLoginButton() {

        var loginForm = $('.mkdf-google-login-holder');
        loginForm.submit(function (e) {
            e.preventDefault();
            window.auth2.signIn();
            mkdfSignInCallback();
        });

    }

    /**
     * Get user data from Google and login user
     */
    function mkdfSignInCallback() {
        var signedIn = window.auth2.isSignedIn.get();
        if (signedIn) {
            var currentUser = window.auth2.currentUser.get(),
                profile = currentUser.getBasicProfile(),
                nonce = $('.mkdf-google-login-holder [name^=mkdf_nonce_google_login]').val(),
                userData = {
                    id: profile.getId(),
                    name: profile.getName(),
                    email: profile.getEmail(),
                    image: profile.getImageUrl(),
                    link: 'https://plus.google.com/' + profile.getId(),
                    nonce: nonce
                },
                data = {
                    action: 'mkdf_membership_check_google_user',
                    response: userData
                };
            $.ajax({
                type: 'POST',
                data: data,
                url: mkdfGlobalVars.vars.mkdfAjaxUrl,
                success: function (data) {
                    var response;
                    response = JSON.parse(data);

                    mkdfRenderAjaxResponseMessage(response);
                    if (response.status == 'success') {
                        window.location = response.redirect;
                    }
                }
            });
        }
    }

    /**
     * Update User Profile
     */
    function mkdfUpdateUserProfile() {
        var updateForm = $('#mkdf-membership-update-profile-form');
        if ( updateForm.length ) {
            var btnText = updateForm.find('button'),
                updatingBtnText = btnText.data('updating-text'),
                updatedBtnText = btnText.data('updated-text');

            updateForm.on('submit', function (e) {
                e.preventDefault();
                var prevBtnText = btnText.html();
                btnText.html(updatingBtnText);

                var ajaxData = {
                    action: 'mkdf_membership_update_user_profile',
                    data: $(this).serialize()
                };

                $.ajax({
                    type: 'POST',
                    data: ajaxData,
                    url: mkdfGlobalVars.vars.mkdfAjaxUrl,
                    success: function (data) {
                        var response;
                        response = JSON.parse(data);

                        // append ajax response html
                        mkdfRenderAjaxResponseMessage(response);
                        if (response.status == 'success') {
                            btnText.html(updatedBtnText);
                            window.location = response.redirect;
                        } else {
                            btnText.html(prevBtnText);
                        }
                    }
                });
                return false;
            });
        }
    }

    function mkdfMembershipFullScreen() {
        var membership = $('.mkdf-membership-main-wrapper');
        var profileContent = $('.page-template-user-dashboard .mkdf-content');
        var footer = $('.mkdf-page-footer');

        var reduceHeight = 0;

        if(!mkdf.body.hasClass('mkdf-header-transparent') && mkdf.windowWidth > 1024) {
            reduceHeight = reduceHeight + mkdfGlobalVars.vars.mkdfMenuAreaHeight + mkdfGlobalVars.vars.mkdfLogoAreaHeight;
        }
        if(footer.length > 0) {
            reduceHeight += footer.outerHeight();
        }

        if(mkdf.windowWidth > 1024) {
            var height = mkdf.windowHeight - reduceHeight;
            profileContent.css({'min-height': height  + 'px'});
        }
    }

	function mkdfMembershipInitDatePicker() {
		$( ".mkdf-membership-input.datepicker" ).datepicker( { dateFormat: "MM dd, yy" });
	}

    function mkdfMembershipRepeater(){
        var wrapper = $('.mkdf-membership-repeater-wrapper');

        if(wrapper.length) {
            wrapper.each(function() {
                var thisWrapper = $(this);
                initCoreRepeater(thisWrapper);
            });
        }

        function initCoreRepeater(wrapper) {
            initRemoveRow(wrapper);
            initEmptyRow(wrapper);

            //Init add new button
            var addNew = wrapper.find('> .mkdf-membership-repeater-add .mkdf-clone'); // add new button
            addNew.on('click', function (e) {
                e.preventDefault();
                var thisAddNew = $(this);
                initCloneRow(wrapper, thisAddNew);
            });
        }

        function initRemoveRow(wrapper){
            var removeBtn = wrapper.find('.mkdf-clone-remove');
            removeBtn.on('click', function (e) {
                e.preventDefault();
                var thisRemoveBtn = $(this);
                var parentRow = thisRemoveBtn.closest('.mkdf-membership-repeater-fields-row');
                var fieldsHolder = thisRemoveBtn.closest('.mkdf-membership-repeater-fields-holder');
                var parentChildRepeater = !!fieldsHolder.hasClass('mkdf-enable-pc');
                var thisHolderRows;

                if(fieldsHolder.hasClass('mkdf-table-layout')) {
                    thisHolderRows = fieldsHolder.find('tbody tr.mkdf-membership-repeater-fields-row');
                } else {
                    if(parentChildRepeater) {
                        var name = thisRemoveBtn.data("name");
                        thisHolderRows = fieldsHolder.find('> .mkdf-membership-repeater-fields-row[data-name=' + name + ']');
                    } else {
                        thisHolderRows = fieldsHolder.find('> .mkdf-membership-repeater-fields-row');
                    }
                }

                if (thisHolderRows.length == 1) {
                    parentRow.find(':input').val('').removeAttr('checked').removeAttr('selected');
                    parentRow.hide();
                } else {
                    parentRow.remove();
                }
            });
        }

        function initEmptyRow(wrapper) {
            var fieldsHolder = wrapper.find('> .mkdf-membership-repeater-fields-holder');
            var thisHolderRows;
            if(fieldsHolder.hasClass('mkdf-table-layout')) {
                thisHolderRows = fieldsHolder.find('tbody tr.mkdf-membership-repeater-fields-row');
            } else {
                thisHolderRows = fieldsHolder.find('> .mkdf-membership-repeater-fields-row');
            }

            thisHolderRows.each(function() {
                var row = $(this);
                if (row.hasClass('mkdf-initially-hidden')) {
                    row.hide();
                }
            });
        }

        function initCloneRow(wrapper, button) {
            var fieldsHolder = wrapper.find('> .mkdf-membership-repeater-fields-holder');
            var parentChildRepeater = !!fieldsHolder.hasClass('mkdf-enable-pc');
            var rows;
            if(fieldsHolder.hasClass('mkdf-table-layout')) {
                 rows = fieldsHolder.find('tbody tr.mkdf-membership-repeater-fields-row');
            } else {
                if(parentChildRepeater) {
                    var name = button.data("name");
                    rows = fieldsHolder.find('> .mkdf-membership-repeater-fields-row[data-name=' + name + ']');
                } else {
                    rows = fieldsHolder.find('> .mkdf-membership-repeater-fields-row');
                }
            }
            var append = true; // flag for showing or appending new row
            if (rows.length == 1 && rows.css('display') == 'none') {
                rows.show();
                append = false;
            }
            if (append) {
                var child = rows.eq(0);
                //FIND FIRST ELEMENT AND DESTROY INITIALIZED SCRIPTS
                child.find('.mkdf-membership-repeater-field').each(function () {
                    var thisField = $(this);
                    thisField.find('select').each(function () {
                        var thisInput = $(this);
                        if(thisInput.hasClass('mkdf-select2')) {
                            $('select.mkdf-select2').select2("destroy");
                        }
                    });
                });

                var rowIndex = button.data('count'); // number of rows for changing id stored as data of add new button
                var firstChild = rows.eq(0).clone(); // clone first row
                var colorPicker = false; // flag for initializing color picker - calling wpColorPicker
                var mediaUploader = false; // flag for initializing media uploader - calling mediaUploader
                var yesNoSwitcher = false; // flag for initializing yes no switcher - calling initSwitch
                var select2 = false; // flag for initializing select2 - calling select2
                var innerRepeater = false; // flag for initializing select2 - calling select2

                firstChild.find('.mkdf-membership-repeater-field').each(function () {
                        var thisField = $(this);
                        var id = thisField.attr('id');
                        if (typeof id !== 'undefined') {
                            thisField.attr('id', id.slice(0, -1) + rowIndex); // change id - first row will have 0 as the last char
                        }
                        thisField.find(':input, textarea').each(function () {
                            var thisInput = $(this);
                            if (thisInput.hasClass('mkdf-membership-gallery-upload-hidden')) {// if input type is media uploader
                                mediaUploader = true;
                                var btn = thisInput.siblings('.mkdf-membership-gallery-upload');
                                mkdfInitMediaRemoveBtn(btn); // get and init new remove btn
                            }
                            else if(thisInput.hasClass('checkbox')) {
                                yesNoSwitcher = true;
                            }
                            thisInput.val('').removeAttr('checked').removeAttr('selected'); //empty fields values
                            if(thisInput.is(':radio')){
                                thisInput.val(fieldsHolder.find(':radio').length);
                            }
                        });
                        thisField.find('select').each(function () {
                            var thisInput = $(this);
                            if(thisInput.hasClass('mkdf-select2')) {
                                select2 = true;
                            }
                        });
                    }
                );
                rows.each(function () {
                    if($(this).find('.mkdf-membership-repeater-wrapper').length) {
                        innerRepeater = true;
                    }
                });
                button.data('count', rowIndex + 1); //increase number of rows
                firstChild.appendTo(fieldsHolder); // append html
                initCoreRepeater(firstChild.find('.mkdf-membership-repeater-wrapper'));
                initRemoveRow(firstChild);
                if (colorPicker) { // reinit colorpickers
                    $('.mkdf-page .my-color-field').wpColorPicker();
                }
                if (mediaUploader) {
                    // deregister click on all media buttons (multiple frames will be opened otherwise)
                    $('.mkdf-media-uploader').off('click', '.mkdf-media-upload-btn');
                    mkdfMembershipUploadImages();
                    mkdfMembershipRemoveMedia();
                }
                if (yesNoSwitcher) {
                    mkdfInitSwitch(); //init yes no switchers
                }
                if (select2) {
                    mkdfSelect2(); //init select2 script
                }
            }

            function mkdfInitMediaRemoveBtn(btn) {
            	var imagesHolder = btn.parents('.mkdf-membership-gallery-holder').find('.mkdf-membership-gallery-images-holder'),
            		removeButton = btn.siblings('.mkdf-membership-remove-image');

            	btn.removeClass("mkdf-binded");
            	removeButton.removeClass("mkdf-binded");

                //remove image src
                imagesHolder.empty();

                //reset meta fields
                btn.siblings('.mkdf-membership-gallery-upload-hidden').each(function(e) {
                    $(this).val('');
                });
            }
        }
    }

    function mkdfMembershipInitSortable() {
        var sortingHolder = $('.mkdf-membership-sortable-holder');
        var enableParentChild = sortingHolder.hasClass('mkdf-enable-pc');
        sortingHolder.sortable({
            handle: '.mkdf-membership-repeater-sort',
            cursor: 'move',
            placeholder: "placeholder",
            start: function(event, ui) {
                ui.placeholder.height(ui.item.height());
                if(enableParentChild) {
                    if (ui.helper.hasClass('second-level')) {
                        ui.placeholder.removeClass('placeholder');
                        ui.placeholder.addClass('placeholder-sub');
                    }
                    else {
                        ui.placeholder.removeClass('placeholder-sub');
                        ui.placeholder.addClass('placeholder');
                    }
                }
            },
            sort: function(event, ui) {
                if(enableParentChild) {
                    var pos;
                    if (ui.helper.hasClass('second-level')) {
                        pos = ui.position.left + 50;
                    }
                    else {
                        pos = ui.position.left;
                    }
                    if (pos >= 75 && !ui.helper.hasClass('second-level') && !ui.helper.hasClass('mkdf-sort-parent')) {
                        ui.placeholder.removeClass('placeholder');
                        ui.placeholder.addClass('placeholder-sub');
                        ui.helper.addClass('second-level');
                    }
                    else if (pos < 30 && ui.helper.hasClass('second-level') && !ui.helper.hasClass('mkdf-sort-child')) {
                        ui.placeholder.removeClass('placeholder-sub');
                        ui.placeholder.addClass('placeholder');
                        ui.helper.removeClass('second-level');
                    }
                }
            }
        });
    }

    function mkdfMembershipInitGeocomplete() {
        var geo_inputs = $(".mkdf-membership-address-field");
        if(geo_inputs.length) {
            geo_inputs.each(function () {
                var geo_input = $(this),
                    reset = geo_input.find("#reset"),
                    inputField = geo_input.find('input'),
                    mapField = geo_input.find('.map_canvas'),
                    countryLimit = geo_input.data('country'),
                    latFieldName = geo_input.data('lat-field'),
                    latField = $("input[name=" + latFieldName + "]"),
                    longFieldName = geo_input.data('long-field'),
                    longField =  $("input[name=" + longFieldName + "]"),
                    initialAddress = inputField.val(),
                    initialLat = latField.val(),
                    initialLong = longField.val();
                inputField.geocomplete({
                    map: mapField,
                    details: ".mkdf-membership-address-elements",
                    detailsAttribute: "data-geo",
                    types: ["geocode", "establishment"],
                    country: countryLimit,
                    markerOptions: {
                        draggable: true
                    }
                });

                inputField.bind("geocode:dragged", function (event, latLng) {
                    latField.val(latLng.lat());
                    longField.val(latLng.lng());
                    $("#reset").show();
                    console.log(latLng);
                    var map = inputField.geocomplete("map");
                    map.panTo(latLng);
                    var geocoder = new google.maps.Geocoder();
                    geocoder.geocode({'latLng': latLng}, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            if (results[0]) {
                                var road = results[0].address_components[1].short_name;
                                var town = results[0].address_components[2].short_name;
                                var county = results[0].address_components[3].short_name;
                                var country = results[0].address_components[4].short_name;
                                inputField.val(road + ' ' + town + ' ' + county + ' ' + country);
                            }
                        }
                    });
                });

                inputField.on('focus',function(){
                    var map = inputField.geocomplete("map");
                    google.maps.event.trigger(map, 'resize')
                });
                reset.on("click",function () {
                    inputField.geocomplete("resetMarker");
                    inputField.val(initialAddress);
                    latField.val(initialLat);
                    longField.val(initialLong);
                    $("#reset").hide();
                    return false;
                });

                $(window).on("load",function () {
                    inputField.trigger("geocode");
                })
            });
        }
    }

    function mkdfMembershipUploadImages(){
    	var galleries = $('.mkdf-membership-gallery-uploader');

    	if (galleries.length){
    		galleries.each(function(){
    			var thisGallery = $(this),
    				inputButton = thisGallery.find('.mkdf-membership-gallery-upload-hidden'),
    				uploadButton = thisGallery.find('.mkdf-membership-gallery-upload'),
    				thisGalleryImageHolder = thisGallery.parents('.mkdf-membership-gallery-holder').find('.mkdf-membership-gallery-images-holder');

    			if (!uploadButton.hasClass("mkdf-binded")) {

					inputButton.on("change", function(e){
						var filesNumber = e.target.files.length;

						thisGalleryImageHolder.empty();

						for (var i = 0, file; file = e.target.files[i] ; i++) {

							var reader = new FileReader();

							// Closure to capture the file information.
							reader.onload = (function(theFile) {
								return function(e) {
									if ($.inArray(theFile.type, ["image/gif", "image/jpeg", "image/png"]) != "-1") {
										thisGalleryImageHolder.append('<li class="mkdf-membership-gallery-image"><img src="' + e.target.result + '" title="' + escape(theFile.name) + '"/></li>');
									} else {
										thisGalleryImageHolder.append('<li class="mkdf-membership-gallery-image"><span class="mkdf-membership-input-text">' + escape(theFile.name) + '</span></li>');
									}
								};
							})(file);

							// Read in the image file as a data URL.
							reader.readAsDataURL(file);
						};
					});

					uploadButton.on("click", function(e){
						e.preventDefault();

						inputButton.trigger("click");
					});
					uploadButton.addClass("mkdf-binded");
				}

    		});
    	}
    }

    function mkdfMembershipRemoveMedia(){
    	var removeMediaBttns = $('.mkdf-membership-remove-image');

    	if (removeMediaBttns.length){
    		removeMediaBttns.each(function(){
    			var thisRemoveMedia = $(this),
    				removeImagesHolder = thisRemoveMedia.parents('.mkdf-membership-gallery-holder').find('.mkdf-membership-gallery-images-holder'),
    				inputHiddenValue = thisRemoveMedia.siblings('.mkdf-membership-media-hidden');


    			if (!thisRemoveMedia.hasClass("mkdf-binded")) {
					thisRemoveMedia.on("click", function(e){
						e.preventDefault();

						inputHiddenValue.val('');

						removeImagesHolder.empty();

					});

					thisRemoveMedia.addClass("mkdf-binded");
				}
    		});
    	}
    }

})(jQuery);