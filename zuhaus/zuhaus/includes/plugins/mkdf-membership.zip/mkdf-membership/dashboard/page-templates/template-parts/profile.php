<div class="mkdf-membership-dashboard-page">
	<div class="mkdf-membership-dashboard-page-content">
		<div class="mkdf-profile-image">
            <?php echo isset($profile_image) ? mkdf_membership_kses_img( $profile_image ) : ''; ?>
        </div>
		<p>
			<span><?php esc_html_e( 'First Name', 'mkdf-membership' ); ?>:</span>
            <?php echo isset($first_name) ? esc_html($first_name) : ''; ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Last Name', 'mkdf-membership' ); ?>:</span>
            <?php echo isset($last_name) ? esc_html($last_name) : ''; ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Email', 'mkdf-membership' ); ?>:</span>
            <?php echo isset($email) ? esc_html($email) : ''; ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Desription', 'mkdf-membership' ); ?>:</span>
            <?php echo isset($description) ? esc_html($description) : ''; ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Website', 'mkdf-membership' ); ?>:</span>
			<a href="<?php echo isset($website) ? esc_url($website) : ''; ?>" target="_blank"><?php echo isset($website) ? esc_html($website) : ''; ?></a>
		</p>
	</div>
</div>
